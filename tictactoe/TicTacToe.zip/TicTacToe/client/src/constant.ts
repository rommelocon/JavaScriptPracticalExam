export const SERVER_URL: string = "http://localhost:8000";
